A HEADS UP ABOUT DUOTONE ICONS ON THE DESKTOP
---------------------------------------------

Duotone icons are a bit different to use than other Font Awesome icons at the moment.

* We currently recommend using the Duotone-specific optimized .svg vector
  files. These can be found in the /svgs/duotone folder of this download.

* Using Ligatures with Duotone Icons is NOT currently recommended - while we've
  included a Duotone ligature-based font file in our Pro desktop download, we
  can't recommend it as a way to use our icons on the desktop. Read the special
  instructions for using duotones with ligatures here -
  https://fontawesome.com/how-to-use/on-the-desktop/referencing-icons/duotone-icons#using-ligatures.

You can read the nitty gritty on the current limitations desktop apps have that
made our Duotone ligature implementation diferent there as well. And our full
Duotone Desktop docs are available at:

https://fontawesome.com/how-to-use/on-the-desktop/referencing-icons/duotone-icons.
